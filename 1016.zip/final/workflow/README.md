# final/workflow — GenOS 워크플로우 Python 단계 (area 02)

**파일 1개 = 캔버스 파이썬 스텝 1개.** 각 파일은 자기완결이며, 내용을 통째로 캔버스에
붙여 넣는다.

> **아홉 스텝 모두 등록한다** — 006 셋(`sfr006_*`)과 018 여섯(`sfr018_*`). 프론트 계약은
> [`../docs/FRONT.md`](../docs/FRONT.md), 실행 점검은 `Test/check/check_workflow_run.py`.

---

## 스텝 목록

| 순서 | 파일 | 시그니처 | 게이트웨이로 부르는 것 |
|---|---|---|---|
| 006-1 | `sfr006_01_context.py` | `async def run(data) -> dict` | 서빙 `POST /chat/context` (+ 스캔 첨부면 MCP `ocr`) |
| 006-2 | `sfr006_02_extract.py` | `async def run(data) -> dict` | 서빙 `POST /chat/extract` |
| 006-3 | `sfr006_03_commit.py` | async generator | 서빙 `POST /chat/commit` |
| 다듬-1 | `sfr018_polish_01_policy.py` | `async def run(data) -> dict` | MCP `lang_policy.resolve_tone` (+ MCP `ocr`) |
| 다듬-2 | `sfr018_polish_02_polish.py` | async generator | 서빙 `POST /polish` + MCP `text_guard` ×3 |
| FAQ-1 | `sfr018_faq_01_source.py` | `async def run(data) -> dict` | `genosUploaded` 읽기 (+ MCP `ocr`) + 서빙 `GET /config` |
| FAQ-2 | `sfr018_faq_02_generate.py` | async generator | 서빙 `POST /generate` |
| 번역-1 | `sfr018_translate_01_detect.py` | `async def run(data) -> dict` | `genosUploaded` 읽기 (+ MCP `ocr`) + MCP `lang_policy.validate_direction` |
| 번역-2 | `sfr018_translate_02_translate.py` | async generator | 서빙 `POST /translate/markdown` + MCP `text_guard` |

---

## 이 디렉토리의 규율 넷

### 1. 파일을 세부 기능별로 쪼개지 않는다

캔버스 파이썬 스텝은 **코드 한 덩어리**로 등록된다. 그래서 로깅 유틸·오류표·게이트웨이
클라이언트가 파일마다 반복된다. **이 중복은 의도한 것이다** — 공용 모듈로 빼면 스텝이
자기완결이 아니게 되어 캔버스에 붙일 수 없다.

같은 이유로 **파일 간 import 이 하나도 없다.** 어떤 파일이든 단독으로 복사해 쓸 수 있다.

### 2. 쓰는 패키지는 `httpx` 하나다

워크플로우 이미지에 포함된 것만 쓸 수 있다 (GENOS_RULES §D.3):
`asyncio, httpx, json, datetime, re, opentelemetry.*, GenOS Logger`.

**`lxml`·`redis`·`jinja2` 는 여기 없다.** 예전 `run_chat.py` 들이 그 셋을 로컬 import
하고 있었고 그게 기본 이미지 변경 요청(11.5.6)에 묶여 있던 원인이다. 지금은 전부
코드서빙/MCP 쪽에 있다.

### 3. 스텝 1 넷과 마지막 스텝은 async generator 다

- **스텝 1 넷**(`*_01_*`): async generator. 스캔 쪽 OCR 진행 안내만 `token` 으로 흘리고
  **`event: result` 를 1회** yield 한다. 엔진(`run_util_v2.stream_wrapper`)이 그 `data` 를
  다음 스텝의 `data` 로 쓴다 — 스텝 위치와 무관하다.
- **`sfr006_02_extract`**: `async def run(data) -> dict`. 흘릴 것이 없다.
- **마지막 스텝**: async generator. 토큰 스트리밍 후 **`event: result` 를 1회** yield.
  (흘리지 않는 스텝도 async generator 형태는 그대로 둔다 — 등록 형태를 바꾸지 않는다.)

generator 안에서 값이 있는 `return X` 는 SyntaxError 다 — `yield {"event": "result", …}`
다음 줄에 값 없는 `return` 을 쓴다.

### 4. 오류는 `data["error"]` 로 흐른다

각 스텝은 첫머리에서 앞 스텝의 `error` 를 확인하고 **있으면 그대로 통과**시킨다 (§A.4).
캔버스에서 `data.error` 로 분기를 걸 수 있다.

> ⚠️ **마지막 스텝이 오류를 사용자에게 말해 준다.** 앞 스텝은 오류 문구를 흘리지 않으므로,
> 마지막 스텝이 `error` 를 받아 문구를 스트리밍하고 `result` 를 내지 않으면 **화면이 빈 채로
> 끝난다.** 세 마지막 스텝 전부 그 경로를 갖고 있다 (`finish_with_error`).

---

## 스트리밍 규약 (가이드 5.2 / §D.4)

```python
await sio_server.emit(event_name, payload, room=sid)
await asyncio.sleep(0)          # ← 없으면 UI 가 마지막에 한꺼번에 받는다
```

전송 단위는 글자가 아니라 **청크(32자)**. `_STREAM_CHUNK_CHARS` 로 각 파일에 있고,
긴 글에서는 `_STREAM_MAX_EMITS`(400)가 조각을 키워 **emit 수가 글 길이에 비례하지
않게** 한다. 짧은 글에서는 예전과 같은 32자다. **사본이 3벌**이라
`check_deploy_contract` 가 갈리면 FAIL 한다.

> **실시간 토큰 스트리밍이 아니다** — 이전 구현도 그랬다. LLM 응답을 **전부 받은 뒤**
> 청크로 잘라 emit 한다. 그래서 LLM 호출을 코드서빙으로 내려도 UI 동작이 달라지지 않는다.
> 진짜 토큰 스트리밍이 필요해지면 코드서빙이 SSE 를 내고 이 스텝이 중계해야 하는데,
> 게이트웨이가 스트리밍 응답을 통과시키는지 **확인되지 않았다.**
>
> **그래서 대기 시간을 연출로 늘리지 않는다** (2026-09-01). 018 두 스텝은 결정적 점검
> 호출을 **먼저 띄워 두고 그 동안** 흘린다 — 순서대로 하면 스트리밍이 순수한 연출이
> 되고 전체 시간만 늘어난다.

### 누가 흘리나 (2026-09-01)

| 스텝 | 흘리나 | 왜 |
|---|---|---|
| `sfr006_03_commit` | ⭕ | 전용 UI 가 없어 **채팅이 곧 화면**이다 |
| `sfr018_polish_02_polish` | ⭕ | 결과가 나올 때까지 화면이 수십 초 비어 있으면 안 된다 |
| `sfr018_translate_02_translate` | ⭕ | 〃 |
| `sfr018_faq_02_generate` | ⭕ | 근거·중복 검증을 통과한 문답을 **항목 단위로** 흘린다 |
| 스텝 1 넷 | 스캔 표식이 있을 때만 | **스캔 OCR 진행 안내만** `<think>` … `</think>` 안에 — `yield` 로 흘린다 (`../docs/README.md` "워크플로우 스트리밍 규약") |

018 두 스텝은 **정본을 흘린다** — `<mark>` 사본이 아니다. 사본을 흘리면 하이라이트가
스트리밍 중에 이미 나타나 "스트리밍부터 하고 끝나면 한 번에 하이라이트" 라는 요구와
어긋나고, 태그가 조각 경계에서 갈려 부스러기가 남는다. **원시 마크다운이 보이는 것은
허용된 동작**이고, `event: result` 가 그 자리를 좌우 하이라이트 비교로 갈아 끼운다.

그리고 **서빙 결과를 받은 뒤에만** 흘린다(번역은 전량 폴백 판정까지 끝난 뒤다).
그 앞에서 흘리면 화면에 글을 뿌려 놓고 오류로 갈아엎게 되어 **답이 나왔다가 사라진다.**
`check_workflow_run` 이 오류 경로에서 토큰이 나오면 FAIL 한다.

---

## 환경 변수 (리비전 정보 > 환경 변수 — 11.5.4)

| 이름 | 필요한 스텝 |
|---|---|
| `GENOS_URL` `GENOS_TOKEN` | 전부 |
| `TEMPLATE_FILL_SERVING_ID` | 006-1·2·3 |
| `TEXT_POLISH_SERVING_ID` | 다듬-2 |
| `FAQ_SERVING_ID` | FAQ-1·2 |
| `TRANSLATION_SERVING_ID` | 번역-2 |
| `TEXT_GUARD_MCP_ID` | 다듬-2, 번역-2 |
| `LANG_POLICY_MCP_ID` | 다듬-1, 번역-1 |
| `OCR_MCP_ID` | 006-1, 다듬-1, 번역-1, FAQ-1 — 첨부 원문에 스캔 쪽 표식(`[[GENON_SCAN doc=… page=N image=…]]`)이 있을 때만 |
| `DISCLAIMER_MCP_ID` | 006-3, 다듬-2, 번역-2, FAQ-2 — 안내 문장을 Disclaimer MCP(`widget_disclaimer`)에서만 받는다. 문구는 그 MCP 도구의 환경변수 `MCP_TOOL_19_{SFR018\|SFR006}_{번호}` 에 있다(`../docs/disclaimer.md`). 못 받으면 확인 불가 문장이 앞에 붙는다 |
| (선택) `POLISH_DEFAULT_DOC_TYPE` `POLISH_DEFAULT_TONE` | 다듬-1 — 화면이 안 준 값의 기본값 |
| (선택) `TRANSLATE_DEFAULT_TARGET_LANG` `TRANSLATE_DEFAULT_SOURCE_LANG` `TRANSLATE_DEFAULT_REGISTER` | 번역-1 — 화면이 안 준 값의 기본값 |

**`HWPX_TEXT_MCP_ID` 는 이 표에서 빠졌다** (2026-09-07). FAQ-1·번역-1 이 캔버스 변수
(`faq_hwpx_path`·`translate_hwpx_path`)로 업로드 원본을 받아 MCP `hwpx_to_markdown` 으로
**한 번 더 파싱**하던 경로를 걷어냈다. 이유는 셋이다:

1. 실환경에서 그 호출이 전부 **406** 이었고(Accept 헤더), 실패가 조용히 전처리기
   산출물로 폴백해서 **"표가 깨진 결과" 로만** 드러났다.
2. 그 캔버스 변수가 업로드 원본 경로를 담아 준다는 **미확인 가정** 위에 있었다.
3. 같은 문서를 **두 번 파싱**했다.

스텝이 받는 첨부 원문은 **전처리기 산출물 `genosUploaded` 하나**다. 첨부용 등록은 파싱만 하고
**청킹하지 않는다**(후보는 `../preprocessor/CLAUDE.md`)(검색용 조문·표 머리말이
섞이면 번역이 원문에 없던 머리말을 번역해 결과물에 싣는다).

**시크릿 기본값은 없다.** 누락되면 각 스텝이 `CONFIG_MISSING`(`ERR-02-00020003`)으로
사용자에게 "서비스 설정이 완료되지 않았습니다" 를 내고 끝낸다 — 값을 로그·응답에
남기지 않는다 (§C).

`GENOS_URL` 이 이미 `/api/gateway` 로 끝나도 되고 아니어도 된다. 각 파일의
`_gateway_base()` 가 흡수한다 — f-string 으로 직접 조립하면 prefix 를 빠뜨린다
(018 두 단위가 실제로 그래서 게이트웨이를 지나지 않고 있었다).

---

### 안내 문구 — Disclaimer MCP

판정(언제 · 몇 건)은 스텝이 하고 **문장은 Disclaimer MCP 에서만** 받는다.
`widget_disclaimer(agent_id, disclaimer_id)` 가 MCP 환경변수 `MCP_TOOL_19_{agent_id}_{disclaimer_id}`
를 그대로 돌려준다 — 숫자를 넘길 자리가 없어서, 숫자가 필요한 안내는 등록 문구 다음 줄에 스텝이 센
상세 줄을 붙인다. 안내 종류 → 번호는 스텝마다 `_DISCLAIMER_NUMBERS`, 등록표는
[`../docs/disclaimer.md`](../docs/disclaimer.md) 다(`check_workflow_run` 이 둘을 대조한다).
함수는 여섯 스텝에 같은 사본(`_disclaimer`, 마지막 스텝 넷은 `_disclaimers` 도)이다.

## 아직 확인하지 못한 것

- **MCP 호출 형식 — 경로는 맞았고 헤더가 틀렸다** (2026-09-07 실환경 확인).
  `{GENOS_URL}/api/gateway/mcp/<id>/mcp` 에 JSON-RPC `tools/call` 을 보내고
  `result.content[].text` 를 JSON 으로 파싱한다 (§H + MCP 표준). 경로는 그대로 통과했는데
  **모든 호출이 `406 Not Acceptable`** 이었다 — MCP 스트리머블 HTTP 서버는 POST 본문을
  읽기 전에 Accept 헤더를 보고 `application/json`·`text/event-stream` 을 **둘 다** 열거하지
  않으면 도구를 부르지도 않고 끊는다(httpx 기본값은 `Accept: */*`). `_MCP_HEADERS` 로
  실어 보내고, 서버가 SSE 프레임으로 답하는 경우를 `_decode_body` 가 해석한다.
  `Test/check/check_workflow_run.py` 의 `_check_mcp_transport`(스텝 5 × 3건)가 지킨다.
  - **다음에 나올 수 있는 실패는 `400 Missing session ID` 다.** 서버가 상태 유지 모드로
    떠 있으면 `initialize` → `Mcp-Session-Id` 핸드셰이크가 필요하다(지금은 `tools/call`
    한 번만 보낸다 — 상태 없는 모드를 전제한다). 그때 고칠 자리도 `_mcp_call` 하나다.
- **워크플로우 스텝 간 `data` 크기 한도.** 문서 본문(`polish_source_text`,
  `translate_source_text`, `faq_source_text`)을 스텝 사이로 넘긴다. 큰 문서에서
  캔버스가 이를 어떻게 다루는지 미확인이다. 한도에 걸리면 본문 대신 **핸들**(세션 키)만
  넘기고 코드서빙이 다시 읽는 형태로 바꿔야 한다.
- **번역 02 스텝 2개는 신규다.** 캔버스에 등록된 적이 없다.
