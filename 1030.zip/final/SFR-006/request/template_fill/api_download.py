"""문서 조립 → 다운로드 응답 — "검증된 값을 파일로 바꾸는" 층.

`api_requests.py` 가 요청을 값으로 바꾸고, 여기서 그 값을 문서로 바꾼다. `main.py` 에는
그 둘을 잇는 배선만 남는다.

## 경계

- **조립 순서(서식 → 채우기 → 블록)는 여기에 없다.** `document.build` 한 곳에만 있다 —
  순서를 여러 곳에 흩어 적으면 점검이 자기가 검증할 순서를 스스로 복제해 무의미해진다.
- **`document.build` 는 HTTP 를 모른다.** 도메인 예외(`TemplateError`)를 `ApiError` 로
  바꾸는 것이 이 파일의 일이고, 그 경계가 여기다.
- **blocking 작업은 전부 `asyncio.to_thread`** (6.9절). zip 해제·XML 파싱이 전부 여기를
  지난다 — 이벤트 루프에서 직접 돌리면 헬스체크가 멈춘다.
- **산출 형식은 hwpx 하나다.** 이 단위는 환경에 아무것도 요구하지 않는다(018 세 단위가
  txt 로 통일되며 얻은 것과 같은 성질이다).
"""

import asyncio
import urllib.parse

from fastapi.responses import Response

from . import document, session_view
from .api_errors import ApiError
from .config import Config
from .error_codes import ERR_API_INPUT, ERR_API_INTERNAL
from .field_judge import normalize_blocks
from .hwpx_blocks import block_style_names
from .hwpx_fields import TemplateError
from .logging_utils import log_warning


async def resolve_blocks(template_id: str, template_bytes: bytes, raw_blocks) -> list:
    """문서 생성 직전에 본문 블록을 검증한다 (`/generate`, `/generate/upload` 공용).

    서식 화이트리스트의 출처가 두 경로에서 다르다 — 등록 템플릿은 색인(캐시)에서,
    업로드 파일은 그 자리에서 파싱해 얻는다. 블록이 없으면 둘 다 하지 않는다
    (블록을 안 쓰는 호출에 파싱·Redis 왕복을 얹지 않는다).
    """
    if not Config.BODY_BLOCKS or not raw_blocks:
        return []
    if template_id:
        _, index = await session_view.load_index(template_id)
        styles = list(index.block_styles)
    else:
        try:
            styles = await asyncio.to_thread(block_style_names, template_bytes)
        except TemplateError as exc:
            raise ApiError(ERR_API_INPUT, str(exc)) from exc

    blocks, rejected = normalize_blocks(raw_blocks, styles)
    if rejected:
        log_warning(
            "본문 블록 일부를 기각했다",
            event="generate_blocks_rejected",
            resource_id=template_id or "upload",
            item_count=len(rejected),
        )
    return blocks


async def build(template_bytes: bytes, values: dict, blocks: list, label: str, disclaimer: str = ""):
    """조립 파이프라인을 스레드에서 돌리고 실패를 HTTP 오류로 바꾼다.

    파이프라인 자체(`document.build`)는 HTTP 를 모른다 — 여기가 그 경계다.
    `disclaimer` 는 세션에 저장된 파일 안 안내문(`file_disclaimer`)이다.
    """
    try:
        return await asyncio.to_thread(
            document.build, template_bytes, values, blocks, label=label, disclaimer=disclaimer
        )
    except TemplateError as exc:
        # 계약: TemplateError 메시지는 도메인 모듈이 만든 고정 안내문만 담는다
        raise ApiError(ERR_API_INPUT, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - 최종 방어선, 원문은 로그 메타에만
        log_warning(
            "hwpx 생성 중 내부 오류",
            event="generate_internal_error",
            resource_id=label,
            error_code=ERR_API_INTERNAL.code,
            error_type=type(exc).__name__,
        )
        raise ApiError(ERR_API_INTERNAL) from exc


def download_response(built, filename_base: str) -> Response:
    """hwpx 바이너리 + 부분 초안/서식/블록 정보를 헤더로 함께 내려준다.

    바이트를 따로 받지 않고 `built.hwpx_bytes` 를 쓴다 — 형식이 하나뿐이라 "무엇을
    내려줄지" 를 호출부가 고를 여지가 없다.

    `X-Document-Format` 은 **값이 하나뿐이어도 남긴다** — 화면이 이 헤더로 확장자를
    정하고 있고, 떼면 프론트가 조용히 빈 값을 읽는다.
    """
    filename = (filename_base or "초안").strip()
    filename = filename.removesuffix(".hwpx")
    quoted = urllib.parse.quote(f"{filename}.hwpx")  # 한글 파일명 → RFC 5987
    return Response(
        content=built.hwpx_bytes,
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": "attachment; filename*=UTF-8''" + quoted,
            # 부분 초안 여부를 파일과 함께 전달 — 누락을 침묵 처리하지 않는다
            "X-Missing-Fields": urllib.parse.quote(",".join(built.missing_fields)),
            "X-Written-Fields": urllib.parse.quote(",".join(built.written_fields)),
            "X-Styled-Fields": urllib.parse.quote(",".join(built.styled_fields)),
            "X-Body-Blocks": str(built.appended_blocks),
            "X-Document-Format": "hwpx",
        },
    )
