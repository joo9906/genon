"""번역 스텝 2/2 — 번역 + 숫자 보존 검증 + 응답 (area 02, **마지막 스텝**).

캔버스에서 하는 일:

```
코드서빙 /translate/markdown  (스켈레톤 분해 + LLM + 용어사전 + 재조립)
      ↓ translated (정본) + `<mark>` 사본 두 벌
MCP text_guard.numeric_issues  (숫자·자릿수 보존 확인)  ← 먼저 띄우고 그 동안 흘린다
      ↓
event: token × N   ← **정본을 흘린다.** 원시 마크다운이 보여도 된다
      ↓
event: result      ← 좌우 하이라이트 비교 + 용어사전 안내로 **갈아 끼운다**
```

## 구조 보존은 코드서빙이 보장한다

마크다운/HTML 표를 **스켈레톤과 셀 텍스트로 분해**해 셀만 번역하고 다시 끼우는 무손실
왕복이 코드서빙 안에 있다. 프롬프트 지시("표를 유지하라")로 처리하지 않는다.
그래서 이 스텝은 구조를 다시 검사하지 않고 **숫자 보존만** 따로 확인한다.

## 숫자 검증을 워크플로우가 부르는 이유

코드서빙 안에도 `numeric_guard` 가 있지만, MCP 로 한 번 더 부르면 **판정 결과가 캔버스에
드러나** 분기를 걸 수 있다(예: 숫자가 어긋나면 사람 검토 노드로). 판정 자체는 같은 규칙이다.
호출이 실패해도 번역 결과 전달은 막지 않는다.

## 문서 출력은 하지 않는다 (요구사항 §3)

원본은 `source_markdown` 으로 함께 내려 UI 가 나란히 보여줄 수 있게 한다.

**내려받기는 txt 하나다** (2026-08-12). 파일은 이 스텝이 만들지 않는다 — 화면의
내려받기 버튼이 코드서빙 `POST /download` 를 직접 부른다(006 다운로드와 같은 배선).
그래서 이 스텝이 낼 것은 `translated_markdown` 까지이고, 그 값이 그대로 파일이 된다.
"""

import asyncio
import json
import logging
import os
import sys

import httpx

# ─────────────────────────────────────────────────────────────
# 로깅 (§C / 가이드 3.8)
# ─────────────────────────────────────────────────────────────
_ALLOWED_LOG_FIELDS = frozenset({
    "event", "trace_id", "request_id", "resource_id", "status",
    "duration_ms", "item_count", "upstream_status", "error_code", "error_type",
})

_LOGGER_NAME = "translate"
_LOG = logging.getLogger(_LOGGER_NAME)


def _emit_log(level: int, message: str, *, event: str, **fields) -> None:
    extra: dict = {"event": event}
    dropped = []
    for key, value in fields.items():
        if key == "event" or key not in _ALLOWED_LOG_FIELDS:
            dropped.append(key)
            continue
        if value is not None:
            extra[key] = value
    if dropped:
        message = f"{message} [dropped_fields={','.join(sorted(dropped))}]"
    _LOG.log(level, message, extra=extra)


# ─────────────────────────────────────────────────────────────
# 디버그 에코 — **테스트 기간 한정** (2026-09-07)
# ─────────────────────────────────────────────────────────────
# 3.8절 화이트리스트가 값을 버리기 때문에(허용 목록 밖은 **이름만** 남는다) 로그만으로는
# 무엇이 왜 실패했는지 알 수 없다 — 특히 게이트웨이가 거절한 **사유는 응답 본문에만**
# 적혀 있고 그 본문은 어디에도 남지 않는다(MCP 406 을 찾는 데 걸린 시간이 그것이다).
# 원인을 찾는 동안 표준 로그와 **별도로** 한 줄을 더 뿜는다. 로그 경로는 그대로다 —
# 걷어낼 때 이 블록과 `_debug_echo` 호출만 지우면 원래 규약으로 돌아온다.
#
# - **stdout 이 아니라 stderr 로 쓴다.** stdout 은 스트리밍·MCP 의 전송 채널이라 섞이면
#   프로토콜이 깨진다 (3.10절이 print 를 금지하는 실제 이유다).
# - `GENON_DEBUG=0` 이면 조용해진다. **기본은 켜짐** — 지금은 원인 추적이 목적이다.
# - 값은 `_DEBUG_MAX_VALUE` 로 자른다. 문서 원문이 통째로 실리면 이 에코 자체가 유출
#   경로가 된다(3.8절).
_DEBUG_MAX_VALUE = 300


def _debug_echo(message: str, *, event: str = "", **fields) -> None:
    if (os.environ.get("GENON_DEBUG") or "1").strip().lower() in {"0", "false", "off"}:
        return
    parts = [f"event={event}"] if event else []
    for key, value in fields.items():
        text = str(value)
        if len(text) > _DEBUG_MAX_VALUE:
            text = f"{text[:_DEBUG_MAX_VALUE]}…(+{len(text) - _DEBUG_MAX_VALUE}자)"
        parts.append(f"{key}={text}")
    sys.stderr.write(f"[DEBUG {_LOGGER_NAME}] {message} | {' '.join(parts)}\n")
    sys.stderr.flush()


def _log_info(message: str, *, event: str, **fields) -> None:
    _emit_log(logging.INFO, message, event=event, **fields)


def _log_warning(message: str, *, event: str, **fields) -> None:
    _debug_echo(f"WARNING {message}", event=event, **fields)
    _emit_log(logging.WARNING, message, event=event, **fields)


# ─────────────────────────────────────────────────────────────
# 오류표 (§A)
# ─────────────────────────────────────────────────────────────
_AREA = "02"

_ERRORS = {
    "UPSTREAM_TIMEOUT": {
        "error_code": f"ERR-{_AREA}-00020001",
        "error_type": "TRANSLATE_UPSTREAM_TIMEOUT",
        "retryable": True,
        "msg": "번역 서비스 응답이 지연되고 있습니다. 잠시 후 다시 시도해 주세요.",
    },
    "UPSTREAM_EXECUTION": {
        "error_code": f"ERR-{_AREA}-00020002",
        "error_type": "TRANSLATE_UPSTREAM_EXECUTION_FAILED",
        "retryable": True,
        "msg": "번역 결과를 생성하지 못했습니다. 잠시 후 다시 시도해 주세요.",
    },
    "CONFIG_MISSING": {
        "error_code": f"ERR-{_AREA}-00020003",
        "error_type": "TRANSLATE_CONFIG_MISSING",
        "retryable": False,
        "msg": "서비스 설정이 완료되지 않았습니다. 관리자에게 문의해 주세요.",
    },
    "UPSTREAM_FINAL": {
        "error_code": f"ERR-{_AREA}-00020003",
        "error_type": "TRANSLATE_UPSTREAM_FINAL",
        "retryable": False,
        "msg": "요청을 처리하지 못했습니다. 관리자에게 문의해 주세요.",
    },
    "INTERNAL": {
        "error_code": f"ERR-{_AREA}-00020003",
        "error_type": "TRANSLATE_INTERNAL",
        "retryable": False,
        "msg": "요청을 처리하지 못했습니다. 잠시 후 다시 시도해 주세요.",
    },
    # 유닛이 **전량** 원문으로 폴백된 상태. 코드서빙은 200 을 내지만(부분 실패도 같은
    # 경로라) 그 본문은 번역이 아니라 **원문 그대로**다 — 그대로 흘려보내면 사용자는
    # 자기가 넣은 글을 번역문으로 받는다. 아래 "전량 폴백" 주석 참고.
    "ALL_FALLBACK": {
        "error_code": f"ERR-{_AREA}-00020002",
        "error_type": "TRANSLATE_ALL_UNITS_FAILED",
        "retryable": True,
        "msg": "번역에 실패해 원문이 그대로 남았습니다. 잠시 후 다시 시도해 주세요.",
    },
}


def _error(key: str) -> dict:
    spec = _ERRORS[key]
    return {
        "error_code": spec["error_code"],
        "msg": spec["msg"],
        "retryable": spec["retryable"],
    }


# ─────────────────────────────────────────────────────────────
# 게이트웨이 호출 (§B / §H)
# ─────────────────────────────────────────────────────────────
_RETRY_STATUS = frozenset({502, 503, 504})

# ─────────────────────────────────────────────────────────────
# 서빙이 "재시도해도 같다" 고 말한 응답인가 (2026-08-14)
# ─────────────────────────────────────────────────────────────
# **상태코드가 아니라 응답 본문의 `error_code` 분류로 본다** (가이드 3.9.2 — 00020003 은
# 통신 실패(00020001)·실행 실패(00020002)가 아닌 나머지 전부이고, 서빙들은 이 분류에
# `retryable=False` 를 붙여 둔다).
#
# 상태코드만 보면 그 판정이 **경계에서 사라진다.** 서빙이 배포 구성 문제(프롬프트 부재·
# Gateway 설정 부재)를 재시도 불가로 갈라 놨는데, 스텝이 500 을 502 와 같은
# `UPSTREAM_EXECUTION`(retryable=True)으로 뭉치면 캔버스는 그대로 재시도를 걸고 사용자는
# **몇 번을 눌러도 같은 자리에서 실패하는 문제에 "잠시 후 다시 시도해 주세요" 를 반복해서
# 본다.** 스텝이 서빙의 판정을 덮어쓰지 않게 한다.
_FINAL_CODE_SUFFIX = "00020003"


def _upstream_kind(response) -> str:
    """실행 실패(`execution`)인가, 서빙이 못 박은 최종 실패(`upstream_final`)인가."""
    try:
        body = response.json()
    except (ValueError, TypeError):  # json.JSONDecodeError 는 ValueError 하위
        return "execution"
    if not isinstance(body, dict):
        return "execution"
    code = str(body.get("error_code") or "")
    return "upstream_final" if code.endswith(_FINAL_CODE_SUFFIX) else "execution"

_CONNECT_TIMEOUT = 3.0
_ATTEMPTS = 2

# 문서 단위 번역은 배치 LLM 호출이 여러 번 돈다 (§B 전체 예산 안에서).
_TRANSLATE_READ_TIMEOUT = 180.0
_GUARD_READ_TIMEOUT = 15.0
# 스트리밍 라우트 (2026-09-09). **정본 서빙에는 없다** — 그 배포에서는 여기 요청이
# 404 나 SSE 아닌 응답으로 떨어지고 `_post_serving("/translate/markdown")` 으로
# 되돌아간다. 즉 이 배선은 반입 판본에서만 흐르고 정본에서는 지금 동작 그대로다.
# SSE 프레임 접두어. 서빙이 `data: {json}` 줄로 보낸다 (`main.py` 의 `_sse`).
_SSE_DATA_PREFIX = "data:"
_TRANSLATE_STREAM_PATH = "/translate/stream"
_TRANSLATE_FINALIZE_PATH = "/translate/finalize"
# finalize 는 **LLM 을 부르지 않는다** (결정적 대조뿐) — 번역 본체와 같은 제한을 두면
# 게이트웨이가 죽었을 때 사용자가 3분을 더 기다린다.
_FINALIZE_READ_TIMEOUT = 30.0


def _gateway_base() -> str:
    base = (os.environ.get("GENOS_URL") or "").strip().rstrip("/")
    if not base:
        raise RuntimeError("GENOS_URL is not configured")
    return base if base.endswith("/api/gateway") else f"{base}/api/gateway"


# ─────────────────────────────────────────────────────────────
# MCP 전송 규약 (2026-09-07 — 실환경 406 수정)
# ─────────────────────────────────────────────────────────────
# MCP 스트리머블 HTTP 서버는 POST 본문을 읽기 **전에 Accept 헤더를 검사한다.**
# `application/json` 과 `text/event-stream` 을 **둘 다** 열거하지 않으면 도구를 부르지도
# 않고 `406 Not Acceptable` 로 끊는다. httpx 기본값은 `Accept: */*` 라 그 검사를
# 통과하지 못한다 — 실환경에서 MCP 경로가 통째로 406 이던 원인이다.
# **코드서빙 POST 에는 붙이지 않는다** (그쪽은 평범한 JSON API 다).
_MCP_HEADERS = {"Accept": "application/json, text/event-stream"}


def _decode_body(response):
    """응답 본문을 파이썬 객체로 되돌린다 (실패 시 `json.JSONDecodeError`).

    MCP 는 같은 `tools/call` 에 **두 가지 모양**으로 답한다 — 서버가 JSON 응답 모드면
    `application/json` 한 덩어리, 기본(스트리머블)이면 `text/event-stream` 프레임에
    담아 준다. `response.json()` 만 쓰면 후자에서 `InvalidJson` 으로 떨어지는데, 그
    상태는 **통신도 되고 도구도 돌았는데 결과만 사라지는** 형태라 원인이 드러나지 않는다.
    """
    ctype = (response.headers.get("content-type") or "").split(";")[0].strip().lower()
    if ctype != "text/event-stream":
        return response.json()

    text = (response.text or "").replace("\r\n", "\n").replace("\r", "\n")
    fallback = None
    for block in text.split("\n\n"):
        data = "\n".join(
            line.split(":", 1)[1].strip()
            for line in block.splitlines()
            if line.startswith("data:")
        ).strip()
        if not data:
            continue
        try:
            frame = json.loads(data)
        except json.JSONDecodeError:
            continue
        # 진행 알림(`method` 를 든 프레임)이 응답보다 **먼저** 실릴 수 있다.
        # 마지막 프레임을 집으면 알림을 응답으로 읽는다 — `result`/`error` 가 응답이다.
        if isinstance(frame, dict) and ("result" in frame or "error" in frame):
            return frame
        fallback = frame
    if fallback is None:
        raise json.JSONDecodeError("no JSON-RPC frame in SSE body", text, 0)
    return fallback


async def _post_json(url: str, payload: dict, *, read_timeout: float,
                     extra_headers: dict | None = None):
    headers = {"Authorization": f"Bearer {(os.environ.get('GENOS_TOKEN') or '').strip()}"}
    if extra_headers:
        headers.update(extra_headers)
    timeout = httpx.Timeout(
        connect=_CONNECT_TIMEOUT, read=read_timeout, write=5.0, pool=_CONNECT_TIMEOUT
    )
    failure = ("transport", "NoAttempt", None)
    async with httpx.AsyncClient(timeout=timeout) as client:
        for attempt in range(_ATTEMPTS):
            _debug_echo(
                "POST 요청",
                event="http_request",
                url=url,
                attempt=attempt + 1,
                accept=headers.get("Accept", "*/*"),
                payload_keys=",".join(sorted(payload)),
            )
            try:
                response = await client.post(url, json=payload, headers=headers)
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                _debug_echo(
                    "전송 실패", event="http_transport_error", url=url, exc=repr(exc)
                )
                failure = ("transport", type(exc).__name__, None)
            else:
                if response.status_code < 400:
                    try:
                        return _decode_body(response), None
                    except (json.JSONDecodeError, ValueError):
                        return None, ("execution", "InvalidJson", response.status_code)
                _debug_echo(
                    "HTTP 오류 응답",
                    event="http_error",
                    url=url,
                    status=response.status_code,
                    content_type=response.headers.get("content-type", ""),
                    body=response.text,
                )
                if response.status_code in _RETRY_STATUS:
                    failure = ("transport", "HTTPStatusError", response.status_code)
                else:
                    return None, (
                        _upstream_kind(response),
                        "HTTPStatusError",
                        response.status_code,
                    )
            if attempt < _ATTEMPTS - 1:
                await asyncio.sleep(0.3 * (attempt + 1))
    return None, failure


async def _post_serving(env_name: str, path: str, payload: dict, *, read_timeout: float):
    serving_id = (os.environ.get(env_name) or "").strip()
    if not serving_id:
        return None, ("config", f"{env_name}_MISSING", None)
    try:
        url = f"{_gateway_base()}/code_serving/{serving_id}/{path.lstrip('/')}"
    except RuntimeError:
        return None, ("config", "GENOS_URL_MISSING", None)
    return await _post_json(url, payload, read_timeout=read_timeout)


async def _stream_serving(env_name: str, path: str, payload: dict, *, read_timeout: float):
    """코드서빙의 **SSE 라우트**를 읽으며 `("token", 글)` 을 내고, 끝에 결과를 낸다.

    `_post_serving` 의 스트리밍 짝이다 — 인자 모양을 맞춰 뒀다. **세 스텝(글다듬이·
    번역·FAQ)이 같은 이름으로 같은 코드를 들고 있어야** `check_deploy_contract` 의
    사본 일치 판정이 갈림을 잡는다(스텝은 자기완결이라 공용 모듈로 뺄 수 없다).

    Yields:
        `("token", str)` — 화면에 흘릴 글.
        `("done", dict)` — 서빙이 마지막에 준 결과 프레임.
        `("failure", tuple)` — `_post_json` 과 **같은 모양의** 3-튜플
            `(kind, error_type, upstream_status)`. 호출부가 그대로 오류표에 매핑한다.

    **한 글자도 흘리지 않은 실패**는 `failure` 로만 나간다 — 호출부가 비스트리밍
    경로로 되돌아갈 수 있어야 한다. 흘린 뒤의 실패는 되돌릴 수 없으므로 그대로 오류다.
    **스트리밍 라우트가 없는 서빙 판본**(정본 `onprem/codeserving/`)에서는 404 나
    SSE 아닌 응답이 와서 여기서 `failure` 가 되고, 호출부가 되돌아간다.
    """
    serving_id = (os.environ.get(env_name) or "").strip()
    if not serving_id:
        yield "failure", ("config", f"{env_name}_MISSING", None)
        return
    try:
        url = f"{_gateway_base()}/code_serving/{serving_id}/{path.lstrip('/')}"
    except RuntimeError:
        yield "failure", ("config", "GENOS_URL_MISSING", None)
        return

    headers = {
        "Authorization": f"Bearer {(os.environ.get('GENOS_TOKEN') or '').strip()}",
        # 스트리밍을 받겠다고 밝힌다. MCP 406 건과 같은 자리다 — 서버가 본문을 읽기
        # **전에** Accept 를 보는 구현이 있다.
        "Accept": "text/event-stream",
    }
    timeout = httpx.Timeout(
        connect=_CONNECT_TIMEOUT, read=read_timeout, write=5.0,
        pool=_CONNECT_TIMEOUT,
    )
    _debug_echo(
        "스트리밍 POST 요청",
        event="http_stream_request",
        url=url,
        accept=headers["Accept"],
        payload_keys=",".join(sorted(payload)),
    )

    emitted = 0
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, json=payload, headers=headers) as response:
                if response.status_code >= 400:
                    # `stream()` 은 지연 읽기다 — 사유를 보려면 먼저 본문을 읽어야 한다.
                    await response.aread()
                    _debug_echo(
                        "스트리밍 HTTP 오류 응답",
                        event="http_stream_error",
                        url=url,
                        status=response.status_code,
                        content_type=response.headers.get("content-type", ""),
                        body=response.text,
                    )
                    yield "failure", (
                        _upstream_kind(response),
                        "HTTPStatusError",
                        response.status_code,
                    )
                    return
                content_type = str(response.headers.get("content-type", "")).lower()
                if "text/event-stream" not in content_type:
                    # 서빙이 스트리밍 라우트를 안 들고 있는 판본이다(배포 어긋남).
                    # 되돌아갈 수 있게 실패로 낸다 — 여기서 본문을 해석하려 들면
                    # 모양을 가정하게 되고, 어긋나면 조용히 빈손이 된다.
                    await response.aread()
                    _debug_echo(
                        "스트리밍을 요청했는데 SSE 가 아니다",
                        event="http_stream_not_sse",
                        url=url,
                        content_type=content_type,
                    )
                    yield "failure", ("execution", "NotEventStream", response.status_code)
                    return

                async for raw_line in response.aiter_lines():
                    line = raw_line.strip()
                    if not line or line.startswith(":"):
                        continue
                    if not line.startswith(_SSE_DATA_PREFIX):
                        continue
                    try:
                        frame = json.loads(line[len(_SSE_DATA_PREFIX):].strip())
                    except (json.JSONDecodeError, ValueError):
                        # 프레임 하나가 깨진 것으로 응답 전체를 버리지 않는다.
                        continue
                    if not isinstance(frame, dict):
                        continue
                    kind = frame.get("type")
                    if kind == "done":
                        yield "done", frame
                        return
                    if kind == "error":
                        # 서빙이 분류해 준 오류다. 상태코드가 아니라 **오류 코드**로
                        # 재시도 여부를 정한다 (`_upstream_kind` 와 같은 규약).
                        code = str(frame.get("error_code") or "")
                        yield "failure", (
                            "upstream_final" if code.endswith("00020003") else "execution",
                            "StreamError",
                            None,
                        )
                        return
                    # **`text` 를 든 프레임은 종류와 무관하게 흘린다.** 단위마다 프레임
                    # 종류가 다르다 — 글다듬이·번역은 `delta` 하나지만 FAQ 는 항목을 열고
                    # 닫는 프레임(`item_open`·`item_close`)도 화면 조각을 들고 온다.
                    # 종류를 여기서 열거하면 단위가 프레임을 하나 더할 때 **세 스텝을 모두**
                    # 고쳐야 하고, 안 고치면 그 조각이 조용히 화면에서 빠진다 — 오류는
                    # 나지 않고 "결과에는 있는데 흐르지 않은 글" 로만 드러난다.
                    text = frame.get("text")
                    if isinstance(text, str) and text:
                        emitted += len(text)
                        yield "token", text
    except (httpx.TimeoutException, httpx.ConnectError) as exc:
        _debug_echo("스트리밍 전송 실패", event="http_stream_transport_error",
                    url=url, exc=repr(exc), emitted=emitted)
        yield "failure", ("transport", type(exc).__name__, None)
        return
    except Exception as exc:  # noqa: BLE001 - 읽는 중 끊김까지
        _debug_echo("스트리밍 읽기 실패", event="http_stream_read_error",
                    url=url, exc=repr(exc), emitted=emitted)
        yield "failure", ("execution", type(exc).__name__, None)
        return

    # `done` 도 `error` 도 없이 끝났다 = 서빙이 결과를 못 냈다. 흘린 글이 있어도
    # 결과가 없으면 화면이 하이라이트·다운로드를 못 받으므로 실패다.
    _debug_echo("스트리밍이 결과 프레임 없이 끝났다",
                event="http_stream_no_done", url=url, emitted=emitted)
    yield "failure", ("execution", "NoDoneFrame", None)


async def _finalize_stream(done: dict, request: dict, log_context: dict) -> dict:
    """`done` 프레임 + `POST /translate/finalize` 를 **비스트리밍 응답 모양으로** 만든다.

    스트리밍 경로만의 모양을 그 뒤 코드가 따로 분기하면 조립이 **두 벌**이 되고, 한쪽만
    고치는 실수는 오류가 아니라 **화면에서만** 드러난다(이 저장소가 여러 번 밟은 형태다).
    여기서 한 번 정규화하면 `/translate/markdown` 을 받은 것과 같은 코드가 흐른다.

    **finalize 실패는 fail-open 이다.** 번역문은 이미 화면에 흘렀으므로 되돌릴 수 없고,
    하이라이트·링크가 없다고 결과를 버리면 **사용자가 방금 본 글이 오류로 바뀐다.**
    사본 자리에는 정본이 들어가고 링크는 빈 값이다(업로드 실패와 같은 규약).
    """
    translated = str(done.get("translated_text") or "")
    normalized = {
        "markdown": translated,
        # 사본을 못 받으면 정본이 그 자리를 채운다 — 화면이 비지는 않는다.
        "markdown_highlighted": translated,
        "source_markdown_highlighted": "",
        "download_url": "",
        "glossary": {},
        # 스트리밍은 **조각** 단위로 돌고 비스트리밍은 **유닛** 단위다. 이름은 다르지만
        # 뒤 코드가 이 값으로 보는 것은 "전부 실패했나" 하나라 뜻이 보존된다.
        "stats": {
            "unit_count": int(done.get("chunk_count") or 0),
            "failed_unit_count": int(done.get("failed_chunk_count") or 0),
        },
        "translation_error": str(done.get("translation_error") or ""),
    }
    if not translated:
        return normalized

    body, failure = await _post_serving(
        "TRANSLATION_SERVING_ID",
        _TRANSLATE_FINALIZE_PATH,
        {
            "original_text": request["markdown"],
            # **`done` 이 준 정본을 그대로 보낸다.** 우리가 델타를 이어 붙인 값과 한
            # 글자라도 다르면 좌표가 밀리고, 그 어긋남은 **하이라이트가 한 칸 밀린
            # 화면**으로만 드러난다.
            "translated_text": translated,
            "target_lang": request["target_lang"],
            "source_lang": request["source_lang"],
            "register": request["register"],
            "title": request["title"],
        },
        read_timeout=_FINALIZE_READ_TIMEOUT,
    )
    if failure is not None:
        # 점검이 돌지 않았다는 사실이 로그에 남아야 "하이라이트가 없는 문서" 와 구분된다
        _log_warning(
            "번역 마무리 호출 실패 — 하이라이트·링크 없이 결과만 전달",
            event="translate_finalize_failed",
            error_type=failure[1],
            upstream_status=failure[2],
            status="degraded",
            **log_context,
        )
        return normalized

    body = body or {}
    normalized["markdown_highlighted"] = str(body.get("markdown_highlighted") or translated)
    normalized["source_markdown_highlighted"] = str(
        body.get("source_markdown_highlighted") or ""
    )
    normalized["download_url"] = str(body.get("download_url") or "")
    normalized["glossary"] = dict(body.get("glossary") or {})
    return normalized



async def _mcp_call(env_name: str, tool: str, arguments: dict, *, read_timeout: float):
    serving_id = (os.environ.get(env_name) or "").strip()
    if not serving_id:
        return None, ("config", f"{env_name}_MISSING", None)
    try:
        url = f"{_gateway_base()}/mcp/{serving_id}/mcp"
    except RuntimeError:
        return None, ("config", "GENOS_URL_MISSING", None)

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": tool, "arguments": arguments},
    }
    body, failure = await _post_json(
        url, payload, read_timeout=read_timeout, extra_headers=_MCP_HEADERS
    )
    if failure is not None:
        return None, failure
    if isinstance(body, dict) and body.get("error"):
        return None, ("execution", "MCP_TOOL_ERROR", None)

    result = (body or {}).get("result") or {}
    contents = result.get("content") or []
    text = "".join(
        str(item.get("text") or "")
        for item in contents
        if isinstance(item, dict) and item.get("type") == "text"
    )
    try:
        return json.loads(text), None
    except json.JSONDecodeError:
        return {"text": text}, None


# ─────────────────────────────────────────────────────────────
# 토큰 스트리밍 (2026-09-01 되살림)
# ─────────────────────────────────────────────────────────────
#
# 2026-08-28 에 없앴다가 요구가 바뀌어 되살렸다 — **번역문이 "AI 가 주루룩 답변하는"
# 것처럼 보여야 한다.** 근거와 규약은 글다듬이 스텝과 같고, 여기만 다른 것이 하나 있다.
#
# ## 여기서는 사본이 **이미 와 있다** — 그래도 정본을 흘린다
#
# 번역은 `<mark>` 사본을 코드서빙이 응답에 함께 실어 준다(글다듬이는 MCP 를 한 번 더
# 불러야 생긴다). 그래서 사본을 흘릴 수도 있지만 **흘리지 않는다**:
#
#   - 태그가 조각 경계에서 갈리면 화면에 `<ma` 같은 부스러기가 남는다.
#   - 흘리는 것과 `result` 가 같아지면 **하이라이트가 스트리밍 중에 이미 나타나** 요구가
#     말한 순서("스트리밍부터 하고 끝나면 한 번에 하이라이트")와 어긋난다.
#   - 두 단위가 다른 것을 흘리면 규약이 갈리고, 그 어긋남은 오류로 드러나지 않는다.
#
# ## 흘리는 시점 — **되돌릴 수 없게 된 뒤에만**
#
# 전량 폴백 판정(아래)까지 끝난 뒤에 흘린다. 그 판정은 응답이 200 이고 본문도 비어
# 있지 않은데 **사용자 원문이 그대로 돌아온** 경우를 오류로 세우는 자리다 — 그 앞에서
# 흘리면 원문을 번역문인 양 화면에 뿌린 뒤 오류로 갈아엎게 된다.
#
# ## 조각 크기는 문서 길이에 따라 늘린다
#
# 32자 고정이면 긴 문서에서 소켓 메시지 수가 문서 길이에 비례한다. 총 emit 수에 상한을
# 두고 조각을 키운다.
_STREAM_CHUNK_CHARS = 32
_STREAM_MAX_EMITS = 400


def _stream_chunks(text: str):
    size = max(_STREAM_CHUNK_CHARS, -(-len(text) // _STREAM_MAX_EMITS))
    for start in range(0, len(text), size):
        yield text[start: start + size]


def _log_context(data: dict) -> dict:
    state = data.get("genos_state") or {}
    return {"trace_id": state.get("trace_id")}


async def run(data: dict):
    try:
        from main_socketio import sio_server
    except ImportError:
        sio_server = None

    if not isinstance(data, dict):
        data = {"question": str(data)}
    sid = data.get("socketIOClientId")
    log_context = _log_context(data)

    async def emit_event(event_name: str, payload):
        if sio_server and sid:
            await sio_server.emit(event_name, payload, room=sid)
            # WebSocket write buffer flush (가이드 5.2·D.4)
            await asyncio.sleep(0)
        return {"event": event_name, "data": payload}

    def _base_payload() -> dict:
        """마지막 스텝의 result 뼈대 — **`{**data}` 를 쓰지 않는다** (2026-08-28).

        `{**data}` 는 앞 스텝이 넣은 값과 캔버스 입력을 전부 실어 나른다. 여기서 필드를
        빼도 그것들이 그대로 프론트에 가므로 **"화면이 보는 값만 싣는다" 가 겉모양만
        지켜진다.** 마지막 스텝이라 다음 스텝에 넘길 `data` 도 없다.

        남기는 것은 `genos_state` 하나 — 플랫폼 추적(`trace_id`)이라 잃으면 로그가
        요청 간에 안 이어진다. 내려받기는 `download_url` 이라 세션 값이 필요 없다.
        """
        state = data.get("genos_state")
        return {"genos_state": state} if state is not None else {}

    async def finish_with_error(error: dict):
        # `error` 는 **오류일 때만** 나간다 (2026-08-28) — 글다듬이 스텝과 같은 규약.
        yield {"event": "result", "data": {**_base_payload(), "error": error}}

    upstream_error = data.get("error")
    if upstream_error:
        _log_warning(
            "앞 스텝 오류를 사용자에게 전달",
            event="translate_error",
            error_code=str(upstream_error.get("error_code") or ""),
            status="final",
            **log_context,
        )
        async for event in finish_with_error(upstream_error):
            yield event
        return

    source_text = str(data.get("translate_source_text") or "")
    target_lang = str(data.get("translate_target_lang") or "")
    source_lang = str(data.get("translate_source_lang") or "")

    translate_payload = {
        "markdown": source_text,
        "target_lang": target_lang,
        "source_lang": source_lang,
        "register": str(data.get("translate_register") or ""),
        # 서빙이 결과 txt 를 굳혀 올릴 때 파일명이 된다 (2026-08-28).
        "title": str(data.get("translate_title") or ""),
    }

    # 1) 번역 — **번역되는 대로 흘린다** (2026-09-09). 스켈레톤 분해·LLM·용어사전·
    #    재조립은 전부 코드서빙 안에 있고(§D.3), 그쪽이 SSE 로 증분을 준다.
    #
    # **흘리는 시점이 전량 폴백 판정보다 앞이다.** 비스트리밍 경로에서는 판정을 끝내고
    # 흘렸는데(원문을 번역문인 양 뿌린 뒤 오류로 갈아엎지 않으려고), 여기서는 흘리면서
    # 간다. 성립하는 근거는 **서빙 쪽 보장**이다 — 전량 실패에서는 한 글자도 흘리지
    # 않는다(실패 조각의 원문은 최종 판정 뒤에만 풀리고 전량 실패면 풀지 않는다).
    # 그 보장이 깨지면 답이 나왔다가 사라지는 화면이 된다.
    body = None
    failure = None
    streamed_chars = 0
    async for stream_kind, stream_value in _stream_serving(
        "TRANSLATION_SERVING_ID",
        _TRANSLATE_STREAM_PATH,
        translate_payload,
        read_timeout=_TRANSLATE_READ_TIMEOUT,
    ):
        if stream_kind == "token":
            streamed_chars += len(stream_value)
            yield await emit_event("token", stream_value)
        elif stream_kind == "done":
            body = stream_value
        else:
            failure = stream_value

    # 하이라이트는 **번역이 끝나야** 정해진다(준수 판정은 번역문 전체를 봐야 하고 좌표는
    # 최종 문자열 기준이다). 그래서 두 번 부른다 — 흘리고, 끝나면 마무리한다.
    if body is not None:
        body = await _finalize_stream(body, translate_payload, log_context)

    # **흘리기 전에 실패했으면 비스트리밍으로 되돌아간다** (글다듬이 스텝과 같은 규약).
    # 서빙이 스트리밍 라우트를 안 들고 있거나(정본 판본이다) 게이트웨이·프록시가 SSE 를
    # 막는 경우다 — 그때 기능이 통째로 죽으면 안 된다. 흘린 뒤라면 되돌릴 수 없으므로
    # 그대로 오류다(같은 글을 두 번 뿌리면 사용자는 그것을 결과물로 읽는다).
    if failure is not None and streamed_chars == 0:
        _log_warning(
            "스트리밍 경로 실패 — 비스트리밍으로 되돌아간다",
            event="translate_stream_fallback",
            error_type=failure[1],
            upstream_status=failure[2],
            **log_context,
        )
        body, failure = await _post_serving(
            "TRANSLATION_SERVING_ID",
            "/translate/markdown",
            translate_payload,
            read_timeout=_TRANSLATE_READ_TIMEOUT,
        )

    if failure is not None:
        kind, error_type, upstream_status = failure
        key = (
            "CONFIG_MISSING" if kind == "config"
            else "UPSTREAM_TIMEOUT" if kind == "transport"
            # 서빙이 재시도 불가로 못 박은 응답은 그 판정을 그대로 따른다
            # (`_upstream_kind` 머리말 참고).
            else "UPSTREAM_FINAL" if kind == "upstream_final"
            else "UPSTREAM_EXECUTION"
        )
        error = _error(key)
        _log_warning(
            "번역 호출 실패",
            event="translate_failed",
            error_code=error["error_code"],
            error_type=error_type,
            upstream_status=upstream_status,
            resource_id=f"{source_lang or 'unknown'}->{target_lang}",
            status="retryable" if error["retryable"] else "final",
            **log_context,
        )
        async for event in finish_with_error(error):
            yield event
        return

    result = body or {}
    # 코드서빙 `api_contract.markdown_payload` 의 필드 이름은 `markdown` 이다.
    # 2026-08-12 까지 `translated_markdown` 을 읽고 있었고 그 키는 응답에 없다 —
    # **번역이 매번 "결과가 비어 있음" 으로 끝나고 있었다.** 옛 이름도 함께 보는 이유는
    # 캔버스에 옛 스텝 사본이 남아 있을 수 있어서다(읽기는 공짜이고 쓰기는 아래에서 둘 다 낸다).
    translated = str(result.get("markdown") or result.get("translated_markdown") or "")
    # 사전 용어에 `<mark>` 이 입혀진 **표시용 사본** (2026-08-14). 없으면 정본을 쓴다 —
    # 옛 리비전의 코드서빙이 이 키를 안 낼 수 있고, 그때 화면이 비면 안 된다.
    highlighted = str(result.get("markdown_highlighted") or translated)
    # 원문 사본 (2026-08-28) — 화면이 원문과 번역문을 좌우로 놓고 비교하므로 **양쪽에**
    # 칠한다. 없으면 원문 그대로 쓴다(옛 리비전의 서빙이 이 키를 안 낼 수 있다).
    source_highlighted = str(result.get("source_markdown_highlighted") or "")
    download_url = str(result.get("download_url") or "") or None
    if not translated:
        error = _error("UPSTREAM_EXECUTION")
        _log_warning(
            "번역 결과가 비어 있음",
            event="translate_empty_result",
            error_code=error["error_code"],
            error_type="EMPTY_RESULT",
            status="retryable",
            **log_context,
        )
        async for event in finish_with_error(error):
            yield event
        return

    glossary = dict(result.get("glossary") or {})
    stats = dict(result.get("stats") or {})

    # ── 전량 폴백을 성공으로 흘려보내지 않는다 (2026-08-14) ──
    #
    # 번역이 실패한 유닛은 **원문이 그대로 남는다**(코드서빙의 설계다 — 한 문장 실패로
    # 문서 전체를 버리지 않기 위해서다). 그래서 LLM 이 통째로 죽어도 응답은 200 이고
    # `markdown` 은 비어 있지 않다. 이 스텝은 그 둘만 보고 있었으므로 **사용자가 자기가
    # 넣은 글을 번역문으로 돌려받았고, 화면 어디에도 실패했다는 표시가 없었다.**
    # `translation_error` 는 응답에 계속 실려 있었지만 아무도 읽지 않았다.
    #
    # 전량 실패는 오류로, 부분 실패는 안내문으로 가른다 — 부분 실패까지 오류로 만들면
    # 한 문장 때문에 번역된 문서 전체를 못 보게 된다.
    translation_error = str(result.get("translation_error") or "")
    unit_count = int(stats.get("unit_count") or 0)
    failed_unit_count = int(stats.get("failed_unit_count") or 0)

    if translation_error and unit_count and failed_unit_count >= unit_count:
        # 설정 부재는 몇 번을 다시 눌러도 같은 자리에서 실패한다 — 재시도를 권하지 않는다
        key = "CONFIG_MISSING" if translation_error == "CONFIG_MISSING" else "ALL_FALLBACK"
        error = _error(key)
        _log_warning(
            "번역 유닛 전량 폴백 — 원문을 번역문으로 내보내지 않는다",
            event="translate_all_units_failed",
            error_code=error["error_code"],
            error_type=translation_error,
            item_count=unit_count,
            status="retryable" if error["retryable"] else "final",
            **log_context,
        )
        async for event in finish_with_error(error):
            yield event
        return

    # 2) 숫자 보존 확인 — 실패해도 번역 결과 전달을 막지 않는다.
    #
    # **먼저 띄워 두고 그 동안 토큰을 흘린다** (2026-09-01). 순서대로 하면 스트리밍이
    # 순수한 연출이 되고 전체 시간만 늘어난다.
    numeric_warnings: list = []
    guard_task = asyncio.ensure_future(
        _mcp_call(
            "TEXT_GUARD_MCP_ID",
            "numeric_issues",
            {"source": source_text, "revised": translated},
            read_timeout=_GUARD_READ_TIMEOUT,
        )
    )

    # 3) 토큰 스트리밍 — **스트리밍 경로로 왔으면 이미 흘렸다** (2026-09-09).
    # 비스트리밍으로 되돌아간 경우에만 여기서 조각내 흘린다 — 그 경로에서는 화면이
    # 아직 비어 있고, 전량 폴백 판정도 끝나 있어 흘린 뒤 갈아엎을 일이 없다.
    # 조건을 빼면 **같은 문서를 두 번 뿌린다.**
    #
    # 어느 쪽이든 흘리는 것은 **정본**이다 (사본이 아니다. 위 머리말 참고).
    if streamed_chars == 0:
        for chunk in _stream_chunks(translated):
            yield await emit_event("token", chunk)

    guard, guard_failure = await guard_task
    if guard_failure is not None:
        # 점검이 돌지 않았다는 사실이 로그에 남아야 "경고 없음" 과 구분된다
        _log_warning(
            "숫자 보존 점검 호출 실패 — 결과는 그대로 전달",
            event="numeric_guard_call_failed",
            error_type=guard_failure[1],
            upstream_status=guard_failure[2],
            status="degraded",
            **log_context,
        )
    else:
        numeric_warnings = [str(w) for w in ((guard or {}).get("issues") or [])]
        if numeric_warnings:
            # 어긋난 값은 남기지 않고 개수만 (3.8절)
            _log_warning(
                "번역문 숫자 불일치 감지",
                event="numeric_mismatch",
                item_count=len(numeric_warnings),
                **log_context,
            )

    # `glossary.source` 는 dict 다. 통째로 찍으면 로그 한 칸에 중괄호가 들어가 검색이
    # 어렵다 — 왜 안 붙었는지를 말하는 `reason` 만 뽑는다(`not_applicable`(중·태·베·러)
    # 과 `file_not_found`(관리자가 손쓸 일)를 이 값으로 가른다).
    glossary_reason = str((glossary.get("source") or {}).get("reason") or "unknown")
    # 번역문이 **쓰지 않은** 사전 용어 수. 준수율(`compliance`)만으로는 "지킬 것이
    # 없어서 1.0" 과 "다 지켜서 1.0" 이 구분되지 않는다 — 건수가 그 둘을 가른다.
    unapplied_count = len(dict(glossary.get("term_map_unapplied") or {}))

    _log_info(
        "번역 완료",
        event="translate_done",
        resource_id=f"{source_lang or 'unknown'}->{target_lang}",
        item_count=int(stats.get("unit_count") or 0),
        status=(
            f"source={data.get('translate_source_kind') or 'unknown'}"
            f" glossary={glossary_reason}"
            f" compliance={glossary.get('compliance', 'n/a')}"
            f" unapplied={unapplied_count}"
            f" fallback={stats.get('fallback_rate', 'n/a')}"
            f" numeric={len(numeric_warnings)}"
        ),
        **log_context,
    )

    # ── 안내문 (2026-08-29) ────────────────────────────────────────────────
    #
    # 2026-08-28 에는 "disclaimer 가 확정되면 붙인다" 며 **판정만 하고 화면에는 아무것도
    # 내보내지 않는** 상태로 뒀다. 그 공백을 payload 의 `notice` 로 메운다.
    #
    # **용어사전 미준수는 우리가 다시 번역하지 않는다** (요구 확정, 2026-08-29). 자동
    # 재번역은 사용자가 고르지 않은 LLM 호출을 한 번 더 쓰면서 결과가 나아진다는 보장이
    # 없고, 화면의 좌우 하이라이트가 이미 **어느 용어가 반영되지 않았는지**를 보여 준다
    # (원문 쪽에만 형광이 남는다). 그래서 사실을 말하고 **다시 번역할지는 사용자가
    # 정한다.**
    #
    # 문구는 **이 파일 안 고정 한국어 문장**이다 (3.8절). 어느 용어인지·어느 문장인지는
    # 싣지 않고 **건수만** 말한다 — 용어와 본문은 문서 내용이고, 자리는 화면의 형광이
    # 이미 가리키고 있다.
    notices: list = []
    if unapplied_count:
        notices.append(
            f"용어사전 용어 {unapplied_count}개가 번역문에 반영되지 않았습니다"
            " (원문에서 형광으로 표시된 자리입니다)."
            " 다시 번역하면 반영될 수 있습니다."
        )
    if failed_unit_count:
        notices.append(
            f"문장 {failed_unit_count}개를 번역하지 못해 원문 그대로 두었습니다."
            " 다시 번역해 주세요."
        )
    if numeric_warnings:
        notices.append(
            f"원문과 번역문의 숫자·날짜가 {len(numeric_warnings)}곳 다릅니다."
            " 결과를 확인해 주세요."
        )

    # 흘린 정본을 **좌우 비교로 갈아 끼운다** (2026-09-01). 스트리밍 중에는 원시
    # 마크다운이 보이고, 이 이벤트가 오면 화면이 그 자리를 하이라이트 두 벌로 바꾼다.
    yield {
        "event": "result",
        "data": {
            **_base_payload(),
            # ── 좌우 비교 두 값 (2026-08-28) ────────────────────────────────
            # 화면은 이 둘을 나란히 놓고 그린다. **양쪽 다 `<mark>` 가 입혀져 있다.**
            # 이름에 `_highlighted` 를 붙이지 않는 이유는 글다듬이 스텝과 같다 — 정본이
            # payload 에서 빠져 사본이 한 벌뿐이라 구분할 대상이 없다.
            # 원문 쪽은 매칭된 용어를 전부 칠하므로, 오른쪽 짝이 비어 있으면
            # "사전 용어인데 번역이 그 말을 안 썼다" 가 화면에 그대로 보인다.
            "original_text": source_highlighted or source_text,
            "translated_text": highlighted,
            # 미리 굳혀 올린 txt 링크. 못 올렸으면 `None`.
            "download_url": download_url,
            # **있을 때만** 실린다 (`error` 와 같은 규약) — 늘 있는 빈 배열은 읽는 쪽이
            # "확인했다" 고 믿게 만든다.
            **({"notice": notices} if notices else {}),
        },
    }

    # ── payload 는 **사용자가 눈으로 보는 값만** 담는다 (2026-08-28) ────────
    #
    # 진단·지표는 우리가 로그로 갖는다 — 위 `event=translate_done` 이 원본 경로·용어사전
    # 사유·준수율·폴백률·숫자 경고 건수를 전부 싣는다. 프론트에 실어 보내면 화면이 그
    # 값을 어떻게 쓸지 각자 정하게 되고, 쓰지 않는 값은 아무도 안 읽는 채로 계약에 남는다.
    #
    #   `translated_markdown`(정본) → 파일이 됐다. 서빙이 굳혀 올리고 링크만 온다
    #   `source_markdown`           → `original_text` 로 이름을 맞췄다 (세 기능 공통)
    #   `translate_pairs`           → 좌우 비교가 **문서 전체 단위**라 유닛을 되짚을 일이
    #                                 없다. 문단별 정렬 비교로 가면 되살린다
    #   `translate_source_kind`     → 진단값. 로그의 `source=` 가 갖는다
    #   `translate_stats`           → 진단값. 로그의 `fallback=` 이 갖는다
    #   `glossary`                  → 준수율·미적용 사유는 **검수용**이다. 사용자가 보는
    #                                 것은 본문의 형광뿐이고, 로그의 `glossary=`·
    #                                 `compliance=` 가 운영 질문에 답한다
    #   `numeric_warnings`          → **`text` 에 `⚠` 줄로 이미 들어 있다.** 건수는 로그의
    #                                 `numeric=` 이 갖는다
